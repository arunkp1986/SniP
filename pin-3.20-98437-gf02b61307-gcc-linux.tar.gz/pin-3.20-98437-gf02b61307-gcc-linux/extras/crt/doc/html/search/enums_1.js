var searchData=
[
  ['tri',['TRI',['../group__OS__APIS__TYPES.html#ga9e15fd2d422b99da6f35cd2fb3f2fe8e',1,'types.h']]]
];
