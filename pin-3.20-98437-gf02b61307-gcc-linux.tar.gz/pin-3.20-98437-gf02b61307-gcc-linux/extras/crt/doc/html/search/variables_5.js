var searchData=
[
  ['protection',['Protection',['../structOS__MEMORY__AT__ADDR__INFORMATION.html#a85e4983266a572dd9add5185534785de',1,'OS_MEMORY_AT_ADDR_INFORMATION']]]
];
