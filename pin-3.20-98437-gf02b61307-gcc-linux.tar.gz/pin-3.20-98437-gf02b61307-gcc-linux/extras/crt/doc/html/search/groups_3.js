var searchData=
[
  ['host_20machine_20queries',['Host machine queries',['../group__OS__APIS__HOST.html',1,'']]]
];
