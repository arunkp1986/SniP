var searchData=
[
  ['ipc',['IPC',['../group__OS__APIS__IPC.html',1,'']]]
];
