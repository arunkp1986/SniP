var searchData=
[
  ['memory',['Memory',['../group__OS__APIS__MEMORY.html',1,'']]],
  ['mutex',['Mutex',['../group__OS__APIS__MUTEX.html',1,'']]]
];
