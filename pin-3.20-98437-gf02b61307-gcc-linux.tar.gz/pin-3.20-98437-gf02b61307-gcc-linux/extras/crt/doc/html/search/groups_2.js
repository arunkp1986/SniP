var searchData=
[
  ['generic_20error_20codes',['Generic error codes',['../group__OS__APIS__DEF.html',1,'']]]
];
