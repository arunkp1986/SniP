var searchData=
[
  ['baseaddress',['BaseAddress',['../structOS__MEMORY__AT__ADDR__INFORMATION.html#aa5d95428913abff4a7c0e5f3e46fd637',1,'OS_MEMORY_AT_ADDR_INFORMATION']]]
];
