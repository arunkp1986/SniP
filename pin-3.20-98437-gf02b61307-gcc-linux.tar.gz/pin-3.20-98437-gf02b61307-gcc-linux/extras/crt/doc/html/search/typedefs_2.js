var searchData=
[
  ['os_5ffile_5fpermission_5ftype',['OS_FILE_PERMISSION_TYPE',['../group__OS__APIS__FILE.html#gaba27a650028099cf71b43ff091ac2ca2',1,'file.h']]],
  ['os_5ffile_5funique_5fid',['OS_FILE_UNIQUE_ID',['../group__OS__APIS__FILE.html#gafb348ecb699757ecbcc0ec68da9701c4',1,'file.h']]],
  ['os_5ffnptrcreateprocess',['OS_FnPtrCreateProcess',['../group__OS__APIS__PROCESS.html#ga8bd862a08dc24374bb76ac7124ef0bcf',1,'process.h']]],
  ['os_5fmutex_5ftype_5fimpl',['OS_MUTEX_TYPE_IMPL',['../group__OS__APIS__MUTEX.html#ga9e0dffecb9651c7be202139b876835d9',1,'mutex.h']]],
  ['os_5fprocess_5fwaitable_5fprocess',['OS_PROCESS_WAITABLE_PROCESS',['../group__OS__APIS__FILE.html#ga125af12a5b69613338937bddae2383dc',1,'process.h']]],
  ['os_5freturn_5fcode',['OS_RETURN_CODE',['../group__OS__APIS__DEF.html#gacaee731b5bf9f9e1bf76a7e1b44e3477',1,'os_return_codes.h']]],
  ['os_5fstruct_5fstat',['OS_STRUCT_STAT',['../group__OS__APIS__FILE.html#ga3df98247374374c26280544c6d930d30',1,'file.h']]]
];
