var searchData=
[
  ['pin_5ftls_5findex',['PIN_TLS_INDEX',['../group__OS__APIS__PIN__TLS.html#ga0987db84fd6e93b83d2e89e436c37ad1',1,'pin-tls.h']]]
];
