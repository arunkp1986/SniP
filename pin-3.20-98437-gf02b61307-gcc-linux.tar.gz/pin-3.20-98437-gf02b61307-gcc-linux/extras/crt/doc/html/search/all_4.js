var searchData=
[
  ['filename_5fbuf_5fsize',['FILENAME_BUF_SIZE',['../group__OS__APIS__TYPES.html#gaba24282e553fe81db10c5299f9995746',1,'types.h']]],
  ['file',['File',['../group__OS__APIS__FILE.html',1,'']]]
];
