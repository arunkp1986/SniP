var searchData=
[
  ['cpu_5fmemory_5fcacheline_5fsize',['CPU_MEMORY_CACHELINE_SIZE',['../group__OS__APIS__TYPES.html#ga381a32123b296d5bddc48f76b3a6e4ea',1,'types.h']]]
];
