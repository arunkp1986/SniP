var searchData=
[
  ['data_20types',['Data types',['../group__OS__APIS__TYPES.html',1,'']]]
];
