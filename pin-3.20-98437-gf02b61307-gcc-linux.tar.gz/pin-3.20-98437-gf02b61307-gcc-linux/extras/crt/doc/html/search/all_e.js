var searchData=
[
  ['signals',['Signals',['../group__OS__APIS__SIGNALS.html',1,'']]],
  ['sa_5fflags',['sa_flags',['../structSIGACTION.html#ab2fb8a90f316d91b9ba458c19d1b0a55',1,'SIGACTION']]],
  ['sa_5frestorer',['sa_restorer',['../structSIGACTION.html#acba757873ba4b82327750c9419e1b627',1,'SIGACTION']]],
  ['shared',['Shared',['../structOS__MEMORY__AT__ADDR__INFORMATION.html#a5f1b8538c7a2f0397f1568edf4bc0b79',1,'OS_MEMORY_AT_ADDR_INFORMATION']]],
  ['sigaction',['SIGACTION',['../structSIGACTION.html',1,'']]]
];
