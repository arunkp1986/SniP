var searchData=
[
  ['sigaction',['SIGACTION',['../structSIGACTION.html',1,'']]]
];
