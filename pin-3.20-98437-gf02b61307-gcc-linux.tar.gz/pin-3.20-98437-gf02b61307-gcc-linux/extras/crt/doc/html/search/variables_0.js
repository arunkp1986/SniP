var searchData=
[
  ['_5fsa_5fhandler_5fptr',['_sa_handler_ptr',['../structSIGACTION.html#ad306ef8350ea4554a0a4cdde674372a6',1,'SIGACTION']]],
  ['_5fsa_5fsigaction',['_sa_sigaction',['../structSIGACTION.html#a2f8bd550d8503fac198aac68b7bba244',1,'SIGACTION']]]
];
