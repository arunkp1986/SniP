var searchData=
[
  ['mapsize',['MapSize',['../structOS__MEMORY__AT__ADDR__INFORMATION.html#aafafff2b58706a51b29d0ef7785eed55',1,'OS_MEMORY_AT_ADDR_INFORMATION']]],
  ['memory',['Memory',['../group__OS__APIS__MEMORY.html',1,'']]],
  ['mutex',['Mutex',['../group__OS__APIS__MUTEX.html',1,'']]]
];
