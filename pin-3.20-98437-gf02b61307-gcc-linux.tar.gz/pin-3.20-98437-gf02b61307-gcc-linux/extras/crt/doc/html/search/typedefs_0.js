var searchData=
[
  ['bool_5ft',['BOOL_T',['../group__OS__APIS__TYPES.html#gad312c486942310e24394e7ea81f8f7e1',1,'types.h']]]
];
